package com.eserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
