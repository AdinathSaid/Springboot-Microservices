package com.contact.service;

import com.contact.entity.Contact;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ContactServiceImpl implements ContactService {

    List<Contact> list=List.of(
            new Contact(101l,"Sachin","sachin@gmail.com",1001l),
            new Contact(102l,"Yuvraj","Yuvi@gmail.com",1002l),
            new Contact(103l,"Dhoni","farm@gmail.com",1003l),
            new Contact(104l,"Mahesh","mahesh@gmail.com",1004l)
    );
    @Override
    public List<Contact> getContactOfUser(Long userid) {
         return list.stream().filter(contact -> contact.getUserid().equals(userid)).collect(Collectors.toList());
    }
}
