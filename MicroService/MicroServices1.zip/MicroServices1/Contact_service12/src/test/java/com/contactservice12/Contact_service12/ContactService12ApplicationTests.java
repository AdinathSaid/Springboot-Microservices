package com.contactservice12.Contact_service12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactService12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
