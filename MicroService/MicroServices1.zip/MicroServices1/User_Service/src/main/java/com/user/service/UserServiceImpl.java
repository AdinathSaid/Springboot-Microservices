package com.user.service;

import com.user.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserServiceImpl implements UserService {


    List<User> list= List.of(
            new User(1001l,"Rohit","1234567890"),
            new User(1002l,"Rahul","0987654321"),
            new User(1003l,"Ramesh","7896543875")
    );

    @Override
    public User getUser(Long id)
    {
        return list.stream().filter(user -> user.getUserid().equals(id)).findAny().orElse(null);
    }
}

