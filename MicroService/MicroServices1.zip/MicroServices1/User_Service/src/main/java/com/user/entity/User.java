package com.user.entity;

import java.util.ArrayList;
import java.util.List;

public class User {
    private Long userid;
    private String name;
    private String mob;

    List<Contact> contacts=new ArrayList<>();

    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMob() {
        return mob;
    }

    public void setMob(String mob) {
        this.mob = mob;
    }

    public List<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }

    public User() {
    }

    public User(Long userid, String name, String mob, List<Contact> contacts) {
        this.userid = userid;
        this.name = name;
        this.mob = mob;
        this.contacts = contacts;
    }

    public User(Long userid, String name, String mob) {
        this.userid = userid;
        this.name = name;
        this.mob = mob;
    }
}
